import React from 'react'


const About = () => {
  return (
    <div className="category">
      <h1>About page</h1>
    </div>
  )
}
export default About
